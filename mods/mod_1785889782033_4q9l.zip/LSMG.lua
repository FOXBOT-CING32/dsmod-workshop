-- ============================================================
--  DS-MOD★ 远程武器模板
--  音效功能：未来版本将会添加
-- ============================================================

NAME = "Laser SMG",
CATEGORY = "weapon",
REGION = "custom",
TYPE = "ranged",

-- 图标（二选一，另一个填 null）
ICON_EMOJI = null,
ICON_IMAGE = "Laser SMG.png",

-- 基础属性
DAMAGE = 25,
ATTACK_SPEED = 0.15,
RADIUS = 20,

-- ============================================================
--  大小控制
-- ============================================================

WEAPON_SCALE = 0.1,       -- 武器显示缩放 (0.1 ~ 5.0)
BULLET_SCALE = 0.8,       -- 子弹显示缩放 (0.1 ~ 5.0)
TRAIL_SCALE = 0.5,        -- 拖尾显示缩放 (0.1 ~ 5.0)
MUZZLE_SCALE = 0.7,       -- 枪口火花缩放 (0.1 ~ 5.0)

-- 远程专属
RANGED_RANGE = 500,
MAX_AMMO = 30,
RESERVE_AMMO = 90,
RELOAD_TIME = 0.1,
BULLET_SPEED = 600,
SPREAD = 0.001,
BULLET_LIFE = 2.0,

-- ============================================================
--  子弹类型配置
-- ============================================================

BULLET_TYPE = "-",       -- "-"=线形炫彩  "·"=典型普通  "?"=无子弹
TRAIL_TYPE = "-",        -- "-"=线形拖尾  "·"=典型拖尾  "?"=无拖尾

-- 特效编码
HIT_EFFECT = 1,          -- 0=无  1=炫彩  2=血液  3=自定义图片
MUZZLE_EFFECT = 2,       -- 0=无  1=闪光  2=炫彩闪光  3=自定义图片

-- ============================================================
--  图片资源（支持本地自定义！）
-- ============================================================

WEAPON_IMAGE = "Laser SMG.png",
BULLET_IMAGE = null,
TRAIL_IMAGE = null,
MUZZLE_IMAGE = null,
HIT_IMAGE = null,

-- ============================================================
--  音效（未来版本将会添加）
-- ============================================================

-- 音效功能即将到来...

-- ============================================================
--  自定义函数
-- ============================================================

function OnShoot(player)
    -- SpawnEffect(player.x, player.y, "muzzle_flash")
end,

function OnHit(target)
    -- SpawnEffect(target.x, target.y, "hit_explosion")
end,

function OnReload(player)
    -- ShowMessage("换弹中...")
end,

function OnEquip(player)
    -- ShowMessage("弹药: " .. player.ammo .. "/" .. player.maxAmmo)
end,

function CreateBullet(player, angle)
    return {
        x = player.x + math.cos(angle) * 30,
        y = player.y + math.sin(angle) * 30,
        vx = math.cos(angle) * BULLET_SPEED,
        vy = math.sin(angle) * BULLET_SPEED,
        damage = DAMAGE,
        life = BULLET_LIFE,
    }
end,

function OnRender(player)
    -- DrawCrosshair(player.x, player.y, 50)
end